**************Generate update.img******************
1.copy image to "rockdev/Image"
2.copy loader to "rockdev"
3.modify parameter and package-file 
4.run mkupdate.sh to make update.img in "rockdev"
***************************************************

**************Unpack update.img********************
run unpack.sh 
unpacking file in the "output"  
***************************************************